#ifndef MENUCONTROL
#define MENUCONTROL

int selectMenuOption();

void menuOption1();

void menuOption2();

void menuOption3();

void menuOption4();

void menuOption5();

void menuOption6();

void menuOption7();

void menuOption8();

#endif